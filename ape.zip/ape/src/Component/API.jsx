import React from 'react';
import {useEffect,useState} from 'react'

function About(){
    const[data,setData]=useState([])
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/posts").then((result)=>{
            result.json().then((resp)=>{
                console.log("result,resp")
                setData(resp)
            })
        })
    },[])
    console.log(data)
    return(
        <div>
            <table style={{
                border:1 
            }}>
                <tr>
                <center><h1>Restful Api Integeration</h1></center>
                 <td>Userid</td>   
                    <td>Id</td>
                   <td>Title</td> 
                    <td>Body</td>
                </tr>
                {
                    data.map((item)=>
                    <tr>
                     <td>{item.userid}</td> 
                     <td>{item.id}</td> 
                     <td>{item.title}</td> 
                     <td>{item.body}</td>   
                        </tr>)
                }
            </table>
        </div>
       
      

    );
}

export default About
