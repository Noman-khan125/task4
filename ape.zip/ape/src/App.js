import React from 'react';
import API from './Component/API'
const App = () => {
  return (
    <>
      <API/>
    </>
  );
}

export default App;

